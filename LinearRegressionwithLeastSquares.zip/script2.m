% Dr. George Azzopardi
% October 2016
% Predictive Analysis

% Linear Regression with Least Squares Method
function script2

if exist('x.mat')
    load x;
    load y;
else
    x = rand(1,50) * 2000 + 700;
    y = 0.14.*x + 50 + rand(1,50)*150-75;
    save x x;
    save y y;
end

f1 = figure;
set(f1,'color',[1 1 1]);
plot(x,y,'r+','markersize',15);
%axis equal;
set(gca,'xlim',[0,3000],'ylim',[0,500],'fontsize',20);
xlabel('Size (feet^2)','fontsize',20);
ylabel('Price (in 1000s of dollars)','fontsize',20);

% Cost function
n = numel(x);
m = rand(1,10000)*10-5;
b = rand(1,10000)*1000-500;

SE = (n*mean(y.^2))-(2.*m.*n.*mean(x.*y))-(2.*b.*n.*mean(y))+((m.^2).*n.*mean(x.^2))+(2.*m.*b.*n.*mean(x))+(n.*(b.^2));
figure('color',[1 1 1]);
plot3(m,b,SE,'b.');
xlabel('m','fontsize',30);
ylabel('b','fontsize',30);
zlabel('SE','fontsize',30);

m1 = (mean(x.*y)-(mean(x)*mean(y)))/(mean(x.^2)-mean(x)^2);
b1 = mean(y) - m1*mean(x);

figure(f1);
hold on;
plot([0 3000],[m1*0+b1,m1*3000+b1],'b-','linewidth',3);